<?php

namespace Nwidart\Modules\Generators;

abstract class Generator
{
}
